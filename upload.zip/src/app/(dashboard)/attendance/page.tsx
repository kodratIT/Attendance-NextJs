export default function Page() {
  return <h1>Attendance!</h1>
}
