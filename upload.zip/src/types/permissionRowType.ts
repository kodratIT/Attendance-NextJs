export type PermissionRowType = {
    id: number
    name: string
    createdDate: string
    assignedTo: string | string[]
  }
  